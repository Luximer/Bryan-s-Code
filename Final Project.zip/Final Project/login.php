<?php
session_start();
include("includes/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {





    $username = $_POST["username"];
    $password = $_POST["password"];


    if (empty($username) || empty($password)) {
        $_SESSION["login_error"] = "Username and password are required.";
        header("Location: index.php"); 
        exit();
    }

    $stmt = $pdo->prepare("SELECT id, username, password, is_admin FROM registration WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user["password"])) {

        $_SESSION["user_id"] = $user["id"];
        $_SESSION["username"] = $user["username"];


        if ($user["is_admin"] == 1) {

            $_SESSION['admin'] = true;
        }


        header("Location: home.php");
        exit();
    } else {

        $_SESSION["login_error"] = "Invalid username or password.";
        header("Location: index.php"); 
        exit();
    }
}



?>