<?php
    $year = date('Y');

    session_start();
    include("includes/db.php");


    if (isset($_SESSION["login_error"])) {
        $login_error = $_SESSION["login_error"];

        unset($_SESSION["login_error"]);
    } else {
        $login_error = ""; 
    }
?>

<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" tpye="text/css" href="style.css">
    <title>Login Page</title>
</head>



<body>
    <div class="container">
    <form action="login.php" method="POST">
        <h2>Login</h2>
        <label for="username">User name:</label>
        <input type="text" id="username" name="username" placeholder="User name" required><br>
        
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" placeholder="Password" required><br>
        
        <p><?php echo $login_error; ?></p>

        <button type="submit">Login</button>


    </form>
    <a href="register.php">
            <button>Register Page</button>
    </a>
    </div>

</body>



</html>