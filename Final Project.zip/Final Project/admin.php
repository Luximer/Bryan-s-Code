<?php
session_start();
include("includes/db.php");


if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {

    header("Location: home.php");
    exit();
}

if (isset($_GET["logout"])) {

    session_destroy();
    header("Location: index.php");
    exit();
}



if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (isset($_POST['addUser'])) {
        $newUsername = $_POST['newUsername'];
        $newPassword = password_hash($_POST['newPassword'], PASSWORD_BCRYPT);
        $isAdmin = isset($_POST['isAdmin']) ? 1 : 0;

        $addUserQuery = "INSERT INTO registration (username, password, is_admin) VALUES (?, ?, ?)";
        $stmt = $pdo->prepare($addUserQuery);
        $stmt->execute([$newUsername, $newPassword, $isAdmin]);
    }


    elseif (isset($_POST['updateUser'])) {
        $userId = $_POST['userId'];
        $updatedUsername = $_POST['updatedUsername'];
        $updatedPassword = password_hash($_POST['updatedPassword'], PASSWORD_BCRYPT);
        $isAdmin = isset($_POST['isAdmin']) ? 1 : 0;

        $updateUserQuery = "UPDATE registration SET username=?, password=?, is_admin=? WHERE id=?";
        $stmt = $pdo->prepare($updateUserQuery);
        $stmt->execute([$updatedUsername, $updatedPassword, $isAdmin, $userId]);
    }


    elseif (isset($_POST['deleteUser'])) {
        $userId = $_POST['userId'];

        $deleteUserQuery = "DELETE FROM registration WHERE id=?";
        $stmt = $pdo->prepare($deleteUserQuery);
        $stmt->execute([$userId]);
    }
}


$getUserQuery = "SELECT id, username, is_admin FROM registration";
$users = $pdo->query($getUserQuery)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>

</head>
<body>

    <div>
        <h2>Welcome to the Admin Page, <?php echo $_SESSION["username"]; ?>!</h2>


        <h3>Add User</h3>
        <form method="post" action="">
            <label for="newUsername">Username:</label>
            <input type="text" name="newUsername" required>
            <label for="newPassword">Password:</label>
            <input type="password" name="newPassword" required>
            <label for="isAdmin">Admin:</label>
            <input type="checkbox" name="isAdmin">
            <button type="submit" name="addUser">Add User</button>
        </form>


        <h3>Users</h3>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Admin</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user) : ?>
                    <tr>
                        <td><?php echo $user['id']; ?></td>
                        <td><?php echo $user['username']; ?></td>
                        <td><?php echo $user['is_admin'] ? 'Yes' : 'No'; ?></td>
                        <td>
                            <form method="post" action="">
                                <input type="hidden" name="userId" value="<?php echo $user['id']; ?>">
                                <label for="updatedUsername">Update Username:</label>
                                <input type="text" name="updatedUsername" required>
                                <label for="updatedPassword">Update Password:</label>
                                <input type="password" name="updatedPassword" required>
                                <label for="isAdmin">Admin:</label>
                                <input type="checkbox" name="isAdmin" <?php echo $user['is_admin'] ? 'checked' : ''; ?>>
                                <button type="submit" name="updateUser">Update</button>
                            </form>

                            <form method="post" action="">
                                <input type="hidden" name="userId" value="<?php echo $user['id']; ?>">
                                <button type="submit" name="deleteUser">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <a href="?logout=true">Logout</a>
    </div>

</body>
</html>