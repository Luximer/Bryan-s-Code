<?php
session_start();
include("includes/db.php");


try {
    $pdo = new PDO('mysql:host=localhost;dbname=project', 'root', 'root');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

$createTableQuery = "CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    review TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES registration(id)
)";
$pdo->exec($createTableQuery);


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reviewContent = isset($_POST['review']) ? $_POST['review'] : "";
    

    $insertReviewQuery = "INSERT INTO reviews (user_id, review) VALUES (:user_id, :review)";
    $stmt = $pdo->prepare($insertReviewQuery);
    $stmt->bindParam(':user_id', $_SESSION['user_id']); 
    $stmt->bindParam(':review', $reviewContent);
    $stmt->execute();
}


$getReviewsQuery = "SELECT r.id, u.username, r.review, r.created_at FROM reviews r
                    JOIN registration u ON r.user_id = u.id
                    ORDER BY r.created_at DESC";
$reviews = $pdo->query($getReviewsQuery)->fetchAll(PDO::FETCH_ASSOC);

if (!isset($_SESSION["user_id"])) {

    header("Location: index.php");
    exit();
}

if (isset($_GET["logout"])) {

    session_destroy();
    header("Location: index.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <title>Review Page</title>
    <style>
        .header {
            padding: 30px;
            text-align: Top Left;
            background: #FA8072;
            color: black;
            font-size: 30px;
        }
        .reviews-container {
            max-width: 600px;
            margin: 20px auto;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .review {
            margin-bottom: 10px;
        }
        a{
    font-size: 15;
}

button{
    background: #555;
    padding: 5px 10px;
    color: #fff;
    border-radius: 5px;
    margin-left: 10px;
    border: none;

}
button:hover{
    opacity: .7;
}

a:hover{
    text-align: left;

}
    </style>
</head>
<body>

    <div class="header">
        <h2>Review Page</h2>
        <a href="?logout=true">
            <button>Logout</button>
        </a>
    </div>

    <div class="reviews-container">

        <form action="reviews.php" method="post">
            <label for="review">Your review:</label>
            <input type="text" name="review" required>
            <button type="submit">Add Review</button>
        </form>


        <?php foreach ($reviews as $rev) : ?>
            <div class="review">
                <strong><?php echo $rev['username']; ?>:</strong> <?php echo $rev['review']; ?>
                <span style="font-size: 12px; color: #888;"><?php echo $rev['created_at']; ?></span>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
