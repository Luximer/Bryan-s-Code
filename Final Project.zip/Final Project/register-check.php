<?php
session_start();
include("includes/db.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = isset($_POST['username']) ? $_POST['username'] : "";
    $password = isset($_POST['password']) ? $_POST['password'] : "";

    try {
        $pdo = new PDO('mysql:host=localhost;dbname=project', 'root', 'root');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }
    
    
    $createTableQuery = "CREATE TABLE IF NOT EXISTS registration (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL,
        is_admin BOOLEAN DEFAULT 0
    )";
    $pdo->exec($createTableQuery);
    
    
    $userStatus = "";
    $pwdEntered = isset($_POST['password']) ? $_POST['password'] : "";
    $pwdHashed = "";
    
    
    function check_password($password) {
        
        $length = strlen($password);
        $hasUppercase = strtolower($password) !== $password;
    
        return ($length >= 1 && $length <= 12 && $hasUppercase);
    }


    if (empty($username) || empty($password)) {
        $_SESSION["registration_status"] = "Username and password are required.";
        header("Location: register.php");
        exit();
    }


    $checkUserQuery = "SELECT * FROM registration WHERE username = :username";
    $stmt = $pdo->prepare($checkUserQuery);
    $stmt->bindParam(':username', $username);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $_SESSION["registration_status"] = "Username already taken. Please choose a different one.";
        header("Location: register.php");
        exit();
    }


    if (!check_password($password)) {
        $_SESSION["registration_status"] = "Invalid password. Password must be 7-12 characters long and contain at least one uppercase letter.";
        header("Location: register.php");
        exit();
    }


    $pwdHashed = password_hash($password, PASSWORD_BCRYPT);
    $insertUserQuery = "INSERT INTO registration (username, password) VALUES (:username, :password)";
    $stmt = $pdo->prepare($insertUserQuery);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $pwdHashed);
    
    if ($stmt->execute()) {
        $_SESSION["registration_status"] = "User successfully registered!";
        header("Location: register.php");
        exit();
    } else {
        $_SESSION["registration_status"] = "Registration failed. Try again.";
        header("Location: register.php");
        exit();
    }
}
?>