


<?php
    $year = date('Y');

    session_start();
    include("includes/db.php");


    if (isset($_SESSION["registration_status"])) {
        $registrationStatus = $_SESSION["registration_status"];

        unset($_SESSION["registration_status"]);
    } else {
        $registrationStatus = ""; 
    }
?>

<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" tpye="text/css" href="style.css">
    <title>Register Page</title>
</head>

<body>
    <div class="container">
    <form action="register-check.php" method="POST">
        <h2>Register</h2>
        <h3>Password must be 7-12 characters long and contain at least one uppercase letter.</h3>
        <label for="username">User name:</label>
        <input type="text" id="username" name="username" placeholder="User name" required><br>
        
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" placeholder="Password" required><br>

        <p><?php echo $registrationStatus; ?></p>

        <button type="submit">Register</button>
    </form>
    <a href="index.php">
            <button>Login Page</button>
    </a>
    </div>
</body>

</html>