<?php
session_start();
include("includes/db.php");


if (!isset($_SESSION["user_id"])) {

    header("Location: index.php");
    exit();
}


if (isset($_GET["logout"])) {

    session_destroy();
    header("Location: index.php");
    exit();
}

?>


<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <title>Home Page</title>
</head>

<style>
.header {
  padding: 30px;
  text-align: Top Left;
  background: #FA8072;
  color: black;
  font-size: 30px;
}
a{
    font-size: 15;
}

button{
    background: #555;
    padding: 5px 10px;
    color: #fff;
    border-radius: 5px;
    margin-left: 10px;
    border: none;

}
button:hover{
    opacity: .7;
}

a:hover{
    text-align: left;

}

</style>

<body>

    <div class="header">
        <h2>Welcome, <?php echo $_SESSION["username"]; ?>!</h2>
        <a href="?logout=true">
            <button>Logout</button>
        </a>
    </div>

    <div class="w3-container w3-green" >
    <a href="admin.php">Go to Admin page (Admin only)</a>
    </div>

    <div class="w3-container w3-blue" >
    <a href="reviews.php">Go to Reviews</a>
    </div>
</body>
</html>